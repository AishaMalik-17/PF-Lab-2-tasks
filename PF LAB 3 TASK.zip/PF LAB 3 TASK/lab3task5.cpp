#include<iostream>
using namespace std;
int main()
{
	int mark1,mark2,mark3,Avg;
	cout<<"Enter marks of first subject: ";
	cin>>mark1;
	cout<<"Enter marks of second subject: ";
	cin>>mark2;
	cout<<"Enter marks of third subject: ";
	cin>>mark3;
	Avg=(mark1+mark2+mark3)/3;
	if(Avg>=90){
		cout<<"Grade:A";
	}
	else if(Avg>=80){
		cout<<"Grade:B";
	}
	else if(Avg>=70){
		cout<<"Grade:C";
	}
	else if(Avg>=60){
		cout<<"Grade:D";
	}
	else{
		cout<<"Grade:F";
	}
	return 0;
}
